USE projectexercise;

ALTER TABLE project
ADD PRIMARY KEY(Proj_Num);

ALTER TABLE employee
ADD PRIMARY KEY(Emp_Num);

ALTER TABLE jobclass
ADD PRIMARY KEY(job_class_code(3));

ALTER TABLE assignment
ADD constraint pkc_Name PRIMARY KEY (Proj_Num, Emp_Num);

ALTER TABLE employee MODIFY Job_Class_Code VARCHAR(3);

ALTER TABLE jobclass MODIFY Job_Class_Code VARCHAR(3);

ALTER TABLE assignment
ADD CONSTRAINT FK_emp_num FOREIGN KEY (Emp_Num)
REFERENCES employee(Emp_Num);

ALTER TABLE assignment
ADD CONSTRAINT FK_proj_num FOREIGN KEY (Proj_Num)
REFERENCES project(Proj_Num);

ALTER TABLE employee
ADD CONSTRAINT FK_job_class_code FOREIGN KEY (Job_Class_Code)
REFERENCES jobclass(Job_Class_Code);

SELECT Count(*) AS ‘CountofProjects’
FROM project;

SELECT Count(Proj_Num) AS 'Count of Projects using an Electrical Engineer'
FROM assignment, employee
WHERE assignment.Emp_Num = employee.Emp_Num
AND Job_Class_Code = 'EE';

SELECT proj_name, FORMAT(SUM(hourly_chargeout_rate*hours_charged),2) AS Project_Charges
FROM assignment, project, jobclass, employee
WHERE assignment.proj_num = project.proj_num
AND assignment.emp_num = employee.emp_num
AND employee.job_class_code = jobclass.job_class_code
GROUP BY proj_name
ORDER BY proj_name;

SELECT emp_lname, emp_fname, 
ROUND(SUM(hourly_chargeout_rate*hours_charged), 2) AS Project_Charges
FROM assignment, project, jobclass, employee
WHERE assignment.proj_num = project.proj_num
AND assignment.emp_num = employee.emp_num
AND employee.job_class_code = jobclass.job_class_code
GROUP BY emp_lname, emp_fname
ORDER BY Project_Charges DESC;

SELECT Proj_Num, FORMAT(SUM(Hours_Charged*Hourly_Chargeout_Rate),2) AS 'ProjectCharges',
(SELECT FORMAT(SUM(Hours_Charged*Hourly_Chargeout_Rate),2)
FROM project AS p, assignment AS a, jobclass AS j, employee as e
WHERE p.Proj_Num = a.Proj_Num
AND j.Job_Class_Code = e.Job_Class_Code
AND a.Emp_Num = e .Emp_Num) AS 'AllProjectCharges'
FROM employee, assignment, jobclass
WHERE employee.Emp_Num = assignment.Emp_Num
AND employee.Job_Class_code = jobclass.Job_Class_code
GROUP BY Proj_Num;

SELECT Count(*) FROM employee;

SELECT Count(*) FROM employee WHERE Job_Class_Code = 'PR';

SELECT DISTINCT Emp_FName, Emp_MName, Emp_LName
FROM employee, assignment
WHERE employee.Emp_Num = assignment.Emp_Num
AND Job_Class_Code = 'PR';

SELECT Job_Class_Desc, count(Emp_Num) AS EmployeeCount
FROM jobclass, employee
WHERE jobclass.Job_Class_Code = employee.Job_Class_Code
GROUP BY Job_Class_Desc
ORDER BY EmployeeCount DESC;

SELECT Proj_Name, count(Emp_Num) AS EmployeesOnProject
FROM project, assignment
WHERE project.Proj_Num = assignment.Proj_Num
GROUP BY Proj_Name
ORDER BY EmployeesOnProject DESC;


SELECT jobclass.job_class_code, ROUND(SUM(hourly_chargeout_rate*hours_charged), 2) 
AS Project_Charges
FROM assignment, project, jobclass, employee
WHERE assignment.proj_num = project.proj_num
AND assignment.emp_num = employee.emp_num
AND employee.job_class_code = jobclass.job_class_code
GROUP BY job_class_code
ORDER BY project_charges DESC;

-- highest average charges--
SELECT jobclass.job_class_code, ROUND(AVG(hourly_chargeout_rate*hours_charged), 2) 
AS Average_Project_Charges
FROM assignment, project, jobclass, employee
WHERE assignment.proj_num = project.proj_num
AND assignment.emp_num = employee.emp_num
AND employee.job_class_code = jobclass.job_class_code
GROUP BY job_class_code
ORDER BY Average_Project_Charges DESC;

SELECT jobclass.job_class_code, 
       ROUND(AVG(hourly_chargeout_rate * hours_charged), 2) 
       AS Average_Project_Charges
FROM assignment
INNER JOIN project ON assignment.proj_num_code = project.proj_num_code
INNER JOIN employee ON assignment.emp_num_code = employee.emp_num_code
INNER JOIN jobclass ON employee.job_class_code = jobclass.job_class_code
GROUP BY jobclass.job_class
ORDER BY Average_Project_Charges DESC;

-- Which employee has the highest total wage for the week
SELECT employee.emp_num_c, ROUND(SUM(hourly_chargeout_rate*hours_charged), 2) 
AS Employee_Wage
FROM assignment, project, jobclass, employee
WHERE assignment.proj_num = project.proj_num
 AND assignment.emp_num = employee.emp_num
AND employee.job_class_code = jobclass.job_class_code
GROUP BY employee.emp_num
ORDER BY Employee_Wage DESC;
-- Employee 105 is the highest paaid for this interval --





