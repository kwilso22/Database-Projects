SELECT * FROM plane.plane_crash_info_updated;
-- How many crashes happened in the USA
Select *
From plane_crash_info_updated
Where country = "USA";
-- How many fatalities happened in Carrier’s with American in the name
Select SUM(Number_of_Fatalities),Carrier, Carrier_two
From plane_crash_info_updated
Where Carrier LIKE "%American%" OR Carrier_two LIKE "%American%"
GROUP BY Carrier,Carrier_two;
-- Update a row to remove a space in the Carrier column
UPDATE plane_crash_info_updated
SET Carrier = 'American Airlines';
-- Find all plane crashes with over 500 fatalities and their rankings
Select Plane_Crash_Ranking, Number_of_Fatalities, Carrier, Carrier_two,Model_of_Plane,Model_of_Plane_two, Country
From plane_crash_info_updated
Where Number_of_Fatalities > 500;
-- What crashes only had one plane involved 
Select Plane_Crash_Ranking, Number_of_Fatalities, Carrier
From plane_crash_info_updated
Where Carrier_two = "N/A";
-- Create a view to determine all the crashes during and after the year 2010
CREATE VIEW recent_crashes AS
SELECT *
FROM plane_crash_info_updated
Where Year >= 2010;
-- Test View
SELECT * From recent_crashes;
-- Creating a stored procedure that returns the total # of fatalities from every crash from every year
delimiter //
create procedure sp_GetTotalFatalities()
Begin
	select year, sum(Number_of_Fatalities)
    from plane_crash_info_updated
    group by year
    order by year;
    End//
    Delimiter ;
    