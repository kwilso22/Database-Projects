use tuckerelectronics;
UPDATE vendor
SET vendor.vendor_name = 'Sam’s Supply Store'
WHERE vendor.vendor_ID = 555;

UPDATE vendor
SET vendor_name = 'John’s Warehouse Deals'
WHERE vendor_ID= 456;

UPDATE item
SET item_name = 'Watch Wearable'
WHERE item_number= 112200;

-- adding PK for vendor table
ALTER TABLE vendor ADD PRIMARY KEY(Vendor_ID); 
-- adding PK for building table
ALTER TABLE building ADD PRIMARY KEY(Building_Code(3));
-- adding PK for room table
ALTER TABLE room ADD CONSTRAINT pkc_room PRIMARY KEY (Building_Code(3), Room_Number); 
-- adding PK for inventory table
ALTER TABLE inventory ADD CONSTRAINT pkc_inventory PRIMARY KEY (Building_Code(3), Room_Number,Item_Number); 
-- adding PK for item table
ALTER TABLE item ADD PRIMARY KEY(Item_Number);
-- adding PK for purcahse table
ALTER TABLE purchase ADD PRIMARY KEY(Purchase_Order_No);
-- adding PK for shipment table
ALTER TABLE shipment ADD CONSTRAINT pkc_shipment PRIMARY KEY (Item_Number, Purchase_Order_No);

-- Changing all Building Code ententies to VarChar with only 3 characters 
ALTER TABLE building MODIFY Building_Code VARCHAR(3); 
ALTER TABLE inventory MODIFY Building_Code VARCHAR(3); 
ALTER TABLE item MODIFY Building_Code VARCHAR(3); 
ALTER TABLE room MODIFY Building_Code VARCHAR(3); 

-- Adding FK
ALTER TABLE shipment ADD CONSTRAINT FK_Item_Number FOREIGN KEY (Item_Number) REFERENCES item(Item_Number); 
ALTER TABLE shipment ADD CONSTRAINT FK_Purchase_Order_No FOREIGN KEY (Purchase_Order_No) REFERENCES purchase(Purchase_Order_No); 

ALTER TABLE item ADD CONSTRAINT FK_Building_Code FOREIGN KEY (Building_Code) REFERENCES building(Building_Code); 
ALTER TABLE item ADD CONSTRAINT FK_Vendor_ID FOREIGN KEY (Vendor_ID) REFERENCES vendor(Vendor_ID); 

ALTER TABLE room ADD CONSTRAINT FK_Building_Code_two FOREIGN KEY (Building_Code) REFERENCES building(Building_Code);
 
ALTER TABLE inventory ADD CONSTRAINT FK_Item_Number_two FOREIGN KEY (Item_Number) REFERENCES item(Item_Number); 
ALTER TABLE inventory ADD CONSTRAINT FK_Building_Code_three FOREIGN KEY (Building_Code) REFERENCES building(Building_Code);

-- Which items are currently on order and from what vendor? Include the vendor name and location
SELECT Shipment.item_number,Shipment.item_quantity_on_order,Vendor.vendor_name, Item.building_code,room.room_number
FROM Shipment
INNER JOIN Item
ON Shipment.item_number = Item.item_number
INNER JOIN Vendor
ON Item.vendor_ID = Vendor.vendor_ID
INNER JOIN Room
ON Item.building_code = Room.building_code;
-- What is the list of inventory (items), along with the location (building and room) and the quantity on hand of each. 
SELECT item_number,item_quantity_on_hand,building_code,room_number
FROM inventory;
-- the aggregated total inventory of each item in each room of each building? Include each item number and name, along with its total
SELECT Inventory.Item_Number,Item.Item_Name,Inventory.Room_Number,Inventory.Building_Code, SUM(Inventory.item_quantity_on_hand) AS 'Total Inventory'
FROM Inventory
INNER JOIN Item 
ON Inventory.building_code = item.building_code
GROUP BY Inventory.Building_Code,Inventory.Room_Number,Inventory.Item_Number,Item.Item_Name;
-- the manager’s name and phone number of each building and the products stored in that building
SELECT Building.Building_Name,Building.Manager_F_name,Building.Manager_M_Initial,Building.Manager_L_Name,Building.Building_Phone_Number,SUM(Inventory.item_quantity_on_hand) AS 'Total Inventory'
FROM Building
INNER JOIN Inventory
ON building.building_code = Inventory.building_code
GROUP BY Building.Building_Name,Building.Manager_F_name,Building.Manager_M_Initial,Building.Manager_L_Name,Building.Building_Phone_Number;
--  items have purchase orders from what vendors with what amounts?
SELECT item.item_number,item.item_name,shipment.purchase_order_no,item.vendor_ID,SUM(shipment.item_cost) AS 'Total Purchase Cost'
FROM Item
INNER JOIN Shipment
ON item.item_number = shipment.item_number
GROUP BY shipment.purchase_order_no,item.item_number,item.item_name,item.vendor_ID ;
-- the aggregated total inventory of all items in all buildings by vendor name
SELECT vendor.vendor_name,item.vendor_id,inventory.building_code,SUM(inventory.item_quantity_on_hand) AS 'Total Inventory'
FROM Vendor
INNER JOIN item
ON vendor.vendor_ID = item.vendor_id
INNER JOIN inventory
ON  item.item_number = inventory.item_number
GROUP BY vendor.vendor_name,item.vendor_id,inventory.building_code;
-- Average cost of items in each purchase order from each vendor
SELECT shipment.purchase_order_no,item.vendor_ID,AVG(shipment.item_cost) AS 'Average Purchase Cost'
FROM Item
INNER JOIN Shipment
ON item.item_number = shipment.item_number
GROUP BY shipment.purchase_order_no,item.vendor_ID ;
-- Shows the expected deliveies times and how much should be expected using a subquery
SELECT Subquery.arrival,sUM(Shipment.item_quantity_on_order) AS 'Total deliveries for that day'
FROM Shipment
INNER JOIN (
    SELECT distinct purchase.arrival_date as arrival, purchase.purchase_order_no
    FROM Purchase
) AS Subquery ON Shipment.purchase_order_no = Subquery.purchase_order_no
GROUP BY Subquery.arrival;