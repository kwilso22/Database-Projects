﻿namespace Project
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.orderInfoGroupBox = new System.Windows.Forms.GroupBox();
            this.menuGroupBox = new System.Windows.Forms.GroupBox();
            this.brewRadioButton = new System.Windows.Forms.RadioButton();
            this.halflbRadioButton = new System.Windows.Forms.RadioButton();
            this.onelbRadioButton = new System.Windows.Forms.RadioButton();
            this.latteRadioButton = new System.Windows.Forms.RadioButton();
            this.espressoRadioButton = new System.Windows.Forms.RadioButton();
            this.cappuccinoRadioButton = new System.Windows.Forms.RadioButton();
            this.sItemLabel = new System.Windows.Forms.Label();
            this.itemLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.calcButton = new System.Windows.Forms.Button();
            this.surchargeCheckBox = new System.Windows.Forms.CheckBox();
            this.quantityTextBox = new System.Windows.Forms.TextBox();
            this.quantityLabel = new System.Windows.Forms.Label();
            this.flavorGroupBox = new System.Windows.Forms.GroupBox();
            this.syrupListBox = new System.Windows.Forms.ListBox();
            this.syrupLabel = new System.Windows.Forms.Label();
            this.sTotalFlavorLabel = new System.Windows.Forms.Label();
            this.totalFlavorLabel = new System.Windows.Forms.Label();
            this.allButton = new System.Windows.Forms.Button();
            this.altButton = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.removeButton = new System.Windows.Forms.Button();
            this.flavorComboBox = new System.Windows.Forms.ComboBox();
            this.volumeCheckBox = new System.Windows.Forms.CheckBox();
            this.discountLabel = new System.Windows.Forms.Label();
            this.totalGroupBox = new System.Windows.Forms.GroupBox();
            this.sNetLabel = new System.Windows.Forms.Label();
            this.sTaxLabel = new System.Windows.Forms.Label();
            this.sSurLabel = new System.Windows.Forms.Label();
            this.netLabel = new System.Windows.Forms.Label();
            this.taxLabel = new System.Windows.Forms.Label();
            this.surLabel = new System.Windows.Forms.Label();
            this.sSubLabel = new System.Windows.Forms.Label();
            this.subLabel = new System.Windows.Forms.Label();
            this.newOrderButton = new System.Windows.Forms.Button();
            this.summaryButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.discountAmountLabel = new System.Windows.Forms.Label();
            this.sDiscountAmountLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.sTotalLabel = new System.Windows.Forms.Label();
            this.discountTextBox = new System.Windows.Forms.TextBox();
            this.discountButton = new System.Windows.Forms.Button();
            this.orderInfoGroupBox.SuspendLayout();
            this.menuGroupBox.SuspendLayout();
            this.flavorGroupBox.SuspendLayout();
            this.totalGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // orderInfoGroupBox
            // 
            this.orderInfoGroupBox.Controls.Add(this.menuGroupBox);
            this.orderInfoGroupBox.Controls.Add(this.sItemLabel);
            this.orderInfoGroupBox.Controls.Add(this.itemLabel);
            this.orderInfoGroupBox.Controls.Add(this.clearButton);
            this.orderInfoGroupBox.Controls.Add(this.calcButton);
            this.orderInfoGroupBox.Controls.Add(this.surchargeCheckBox);
            this.orderInfoGroupBox.Controls.Add(this.quantityTextBox);
            this.orderInfoGroupBox.Controls.Add(this.quantityLabel);
            this.orderInfoGroupBox.Location = new System.Drawing.Point(12, 23);
            this.orderInfoGroupBox.Name = "orderInfoGroupBox";
            this.orderInfoGroupBox.Size = new System.Drawing.Size(729, 269);
            this.orderInfoGroupBox.TabIndex = 0;
            this.orderInfoGroupBox.TabStop = false;
            this.orderInfoGroupBox.Text = "Order Information";
            this.orderInfoGroupBox.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // menuGroupBox
            // 
            this.menuGroupBox.Controls.Add(this.brewRadioButton);
            this.menuGroupBox.Controls.Add(this.halflbRadioButton);
            this.menuGroupBox.Controls.Add(this.onelbRadioButton);
            this.menuGroupBox.Controls.Add(this.latteRadioButton);
            this.menuGroupBox.Controls.Add(this.espressoRadioButton);
            this.menuGroupBox.Controls.Add(this.cappuccinoRadioButton);
            this.menuGroupBox.Location = new System.Drawing.Point(354, 43);
            this.menuGroupBox.Name = "menuGroupBox";
            this.menuGroupBox.Size = new System.Drawing.Size(355, 183);
            this.menuGroupBox.TabIndex = 0;
            this.menuGroupBox.TabStop = false;
            this.menuGroupBox.Text = "Menu Selections";
            // 
            // brewRadioButton
            // 
            this.brewRadioButton.AutoSize = true;
            this.brewRadioButton.Location = new System.Drawing.Point(146, 138);
            this.brewRadioButton.Name = "brewRadioButton";
            this.brewRadioButton.Size = new System.Drawing.Size(101, 24);
            this.brewRadioButton.TabIndex = 13;
            this.brewRadioButton.Text = "F&resh Brew";
            this.brewRadioButton.UseVisualStyleBackColor = true;
            // 
            // halflbRadioButton
            // 
            this.halflbRadioButton.AutoSize = true;
            this.halflbRadioButton.Location = new System.Drawing.Point(146, 87);
            this.halflbRadioButton.Name = "halflbRadioButton";
            this.halflbRadioButton.Size = new System.Drawing.Size(200, 24);
            this.halflbRadioButton.TabIndex = 11;
            this.halflbRadioButton.Text = "Coffee Beans (1 /&2lb bag)";
            this.halflbRadioButton.UseVisualStyleBackColor = true;
            // 
            // onelbRadioButton
            // 
            this.onelbRadioButton.AutoSize = true;
            this.onelbRadioButton.Location = new System.Drawing.Point(146, 42);
            this.onelbRadioButton.Name = "onelbRadioButton";
            this.onelbRadioButton.Size = new System.Drawing.Size(186, 24);
            this.onelbRadioButton.TabIndex = 9;
            this.onelbRadioButton.Text = "Coffee Beans (&1 lb bag)";
            this.onelbRadioButton.UseVisualStyleBackColor = true;
            // 
            // latteRadioButton
            // 
            this.latteRadioButton.AutoSize = true;
            this.latteRadioButton.Location = new System.Drawing.Point(25, 138);
            this.latteRadioButton.Name = "latteRadioButton";
            this.latteRadioButton.Size = new System.Drawing.Size(63, 24);
            this.latteRadioButton.TabIndex = 12;
            this.latteRadioButton.Text = "&Latte";
            this.latteRadioButton.UseVisualStyleBackColor = true;
            this.latteRadioButton.CheckedChanged += new System.EventHandler(this.latteRadioButton_CheckedChanged);
            // 
            // espressoRadioButton
            // 
            this.espressoRadioButton.AutoSize = true;
            this.espressoRadioButton.Location = new System.Drawing.Point(25, 87);
            this.espressoRadioButton.Name = "espressoRadioButton";
            this.espressoRadioButton.Size = new System.Drawing.Size(87, 24);
            this.espressoRadioButton.TabIndex = 10;
            this.espressoRadioButton.Text = "&Espresso";
            this.espressoRadioButton.UseVisualStyleBackColor = true;
            // 
            // cappuccinoRadioButton
            // 
            this.cappuccinoRadioButton.AutoSize = true;
            this.cappuccinoRadioButton.Checked = true;
            this.cappuccinoRadioButton.Location = new System.Drawing.Point(25, 42);
            this.cappuccinoRadioButton.Name = "cappuccinoRadioButton";
            this.cappuccinoRadioButton.Size = new System.Drawing.Size(108, 24);
            this.cappuccinoRadioButton.TabIndex = 8;
            this.cappuccinoRadioButton.TabStop = true;
            this.cappuccinoRadioButton.Text = "Cappucc&ino";
            this.cappuccinoRadioButton.UseVisualStyleBackColor = true;
            // 
            // sItemLabel
            // 
            this.sItemLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sItemLabel.Location = new System.Drawing.Point(126, 231);
            this.sItemLabel.Name = "sItemLabel";
            this.sItemLabel.Size = new System.Drawing.Size(122, 25);
            this.sItemLabel.TabIndex = 7;
            // 
            // itemLabel
            // 
            this.itemLabel.AutoSize = true;
            this.itemLabel.Location = new System.Drawing.Point(26, 232);
            this.itemLabel.Name = "itemLabel";
            this.itemLabel.Size = new System.Drawing.Size(97, 20);
            this.itemLabel.TabIndex = 6;
            this.itemLabel.Text = "Item amount:";
            // 
            // clearButton
            // 
            this.clearButton.Enabled = false;
            this.clearButton.Location = new System.Drawing.Point(192, 156);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(105, 49);
            this.clearButton.TabIndex = 5;
            this.clearButton.Text = "C&lear for Next Item";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(26, 156);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(105, 49);
            this.calcButton.TabIndex = 4;
            this.calcButton.Text = "&Calculate Selection";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // surchargeCheckBox
            // 
            this.surchargeCheckBox.AutoSize = true;
            this.surchargeCheckBox.Location = new System.Drawing.Point(21, 86);
            this.surchargeCheckBox.Name = "surchargeCheckBox";
            this.surchargeCheckBox.Size = new System.Drawing.Size(104, 24);
            this.surchargeCheckBox.TabIndex = 3;
            this.surchargeCheckBox.Text = "S&urcharge?";
            this.surchargeCheckBox.UseVisualStyleBackColor = true;
            // 
            // quantityTextBox
            // 
            this.quantityTextBox.Location = new System.Drawing.Point(126, 43);
            this.quantityTextBox.Name = "quantityTextBox";
            this.quantityTextBox.Size = new System.Drawing.Size(125, 27);
            this.quantityTextBox.TabIndex = 2;
            this.quantityTextBox.TextChanged += new System.EventHandler(this.quantityTextBox_TextChanged);
            this.quantityTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.quantity_KeyPress);
            // 
            // quantityLabel
            // 
            this.quantityLabel.AutoSize = true;
            this.quantityLabel.Location = new System.Drawing.Point(26, 43);
            this.quantityLabel.Name = "quantityLabel";
            this.quantityLabel.Size = new System.Drawing.Size(68, 20);
            this.quantityLabel.TabIndex = 1;
            this.quantityLabel.Text = "Quantity:";
            this.quantityLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // flavorGroupBox
            // 
            this.flavorGroupBox.Controls.Add(this.syrupListBox);
            this.flavorGroupBox.Controls.Add(this.syrupLabel);
            this.flavorGroupBox.Controls.Add(this.sTotalFlavorLabel);
            this.flavorGroupBox.Controls.Add(this.totalFlavorLabel);
            this.flavorGroupBox.Controls.Add(this.allButton);
            this.flavorGroupBox.Controls.Add(this.altButton);
            this.flavorGroupBox.Controls.Add(this.addButton);
            this.flavorGroupBox.Controls.Add(this.removeButton);
            this.flavorGroupBox.Controls.Add(this.flavorComboBox);
            this.flavorGroupBox.Location = new System.Drawing.Point(13, 298);
            this.flavorGroupBox.Name = "flavorGroupBox";
            this.flavorGroupBox.Size = new System.Drawing.Size(376, 261);
            this.flavorGroupBox.TabIndex = 1;
            this.flavorGroupBox.TabStop = false;
            this.flavorGroupBox.Text = "Fresh Brewed Flavors and Syrups";
            // 
            // syrupListBox
            // 
            this.syrupListBox.FormattingEnabled = true;
            this.syrupListBox.ItemHeight = 20;
            this.syrupListBox.Location = new System.Drawing.Point(19, 175);
            this.syrupListBox.Name = "syrupListBox";
            this.syrupListBox.Size = new System.Drawing.Size(228, 64);
            this.syrupListBox.TabIndex = 18;
            this.syrupListBox.SelectedIndexChanged += new System.EventHandler(this.syrupListBox_SelectedIndexChanged);
            // 
            // syrupLabel
            // 
            this.syrupLabel.AutoSize = true;
            this.syrupLabel.Location = new System.Drawing.Point(14, 145);
            this.syrupLabel.Name = "syrupLabel";
            this.syrupLabel.Size = new System.Drawing.Size(99, 20);
            this.syrupLabel.TabIndex = 17;
            this.syrupLabel.Text = "Syrup Flavors:";
            // 
            // sTotalFlavorLabel
            // 
            this.sTotalFlavorLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sTotalFlavorLabel.Location = new System.Drawing.Point(125, 96);
            this.sTotalFlavorLabel.Name = "sTotalFlavorLabel";
            this.sTotalFlavorLabel.Size = new System.Drawing.Size(122, 25);
            this.sTotalFlavorLabel.TabIndex = 16;
            // 
            // totalFlavorLabel
            // 
            this.totalFlavorLabel.AutoSize = true;
            this.totalFlavorLabel.Location = new System.Drawing.Point(14, 97);
            this.totalFlavorLabel.Name = "totalFlavorLabel";
            this.totalFlavorLabel.Size = new System.Drawing.Size(95, 20);
            this.totalFlavorLabel.TabIndex = 15;
            this.totalFlavorLabel.Text = "Total Flavors:";
            // 
            // allButton
            // 
            this.allButton.Location = new System.Drawing.Point(265, 206);
            this.allButton.Name = "allButton";
            this.allButton.Size = new System.Drawing.Size(105, 49);
            this.allButton.TabIndex = 22;
            this.allButton.Text = "Remove All &Flavors";
            this.allButton.UseVisualStyleBackColor = true;
            this.allButton.Click += new System.EventHandler(this.allButton_Click);
            // 
            // altButton
            // 
            this.altButton.Location = new System.Drawing.Point(265, 145);
            this.altButton.Name = "altButton";
            this.altButton.Size = new System.Drawing.Size(105, 49);
            this.altButton.TabIndex = 21;
            this.altButton.Text = "A&dd Flavor Alt";
            this.altButton.UseVisualStyleBackColor = true;
            this.altButton.Click += new System.EventHandler(this.altButton_Click);
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(265, 90);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(105, 49);
            this.addButton.TabIndex = 20;
            this.addButton.Text = "&Add Flavor";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // removeButton
            // 
            this.removeButton.Location = new System.Drawing.Point(265, 26);
            this.removeButton.Name = "removeButton";
            this.removeButton.Size = new System.Drawing.Size(105, 49);
            this.removeButton.TabIndex = 19;
            this.removeButton.Text = "&Remove Flavor";
            this.removeButton.UseVisualStyleBackColor = true;
            this.removeButton.Click += new System.EventHandler(this.removeButton_Click);
            // 
            // flavorComboBox
            // 
            this.flavorComboBox.FormattingEnabled = true;
            this.flavorComboBox.Location = new System.Drawing.Point(6, 39);
            this.flavorComboBox.Name = "flavorComboBox";
            this.flavorComboBox.Size = new System.Drawing.Size(241, 28);
            this.flavorComboBox.TabIndex = 14;
            this.flavorComboBox.SelectedIndexChanged += new System.EventHandler(this.flavorComboBox_SelectedIndexChanged);
            // 
            // volumeCheckBox
            // 
            this.volumeCheckBox.AutoSize = true;
            this.volumeCheckBox.Location = new System.Drawing.Point(20, 570);
            this.volumeCheckBox.Name = "volumeCheckBox";
            this.volumeCheckBox.Size = new System.Drawing.Size(143, 24);
            this.volumeCheckBox.TabIndex = 23;
            this.volumeCheckBox.Text = "&Volume Discount";
            this.volumeCheckBox.UseVisualStyleBackColor = true;
            this.volumeCheckBox.CheckedChanged += new System.EventHandler(this.volumeCheckBox_CheckedChanged);
            // 
            // discountLabel
            // 
            this.discountLabel.AutoSize = true;
            this.discountLabel.Location = new System.Drawing.Point(12, 612);
            this.discountLabel.Name = "discountLabel";
            this.discountLabel.Size = new System.Drawing.Size(124, 20);
            this.discountLabel.TabIndex = 39;
            this.discountLabel.Text = "Enter Discount: %";
            this.discountLabel.Visible = false;
            this.discountLabel.Click += new System.EventHandler(this.discountLabel_Click);
            // 
            // totalGroupBox
            // 
            this.totalGroupBox.Controls.Add(this.sNetLabel);
            this.totalGroupBox.Controls.Add(this.sTaxLabel);
            this.totalGroupBox.Controls.Add(this.sSurLabel);
            this.totalGroupBox.Controls.Add(this.netLabel);
            this.totalGroupBox.Controls.Add(this.taxLabel);
            this.totalGroupBox.Controls.Add(this.surLabel);
            this.totalGroupBox.Controls.Add(this.sSubLabel);
            this.totalGroupBox.Controls.Add(this.subLabel);
            this.totalGroupBox.Location = new System.Drawing.Point(395, 298);
            this.totalGroupBox.Name = "totalGroupBox";
            this.totalGroupBox.Size = new System.Drawing.Size(346, 255);
            this.totalGroupBox.TabIndex = 2;
            this.totalGroupBox.TabStop = false;
            this.totalGroupBox.Text = "Order Totals";
            // 
            // sNetLabel
            // 
            this.sNetLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sNetLabel.Location = new System.Drawing.Point(142, 200);
            this.sNetLabel.Name = "sNetLabel";
            this.sNetLabel.Size = new System.Drawing.Size(122, 25);
            this.sNetLabel.TabIndex = 31;
            // 
            // sTaxLabel
            // 
            this.sTaxLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sTaxLabel.Location = new System.Drawing.Point(142, 159);
            this.sTaxLabel.Name = "sTaxLabel";
            this.sTaxLabel.Size = new System.Drawing.Size(122, 25);
            this.sTaxLabel.TabIndex = 29;
            // 
            // sSurLabel
            // 
            this.sSurLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sSurLabel.Location = new System.Drawing.Point(142, 104);
            this.sSurLabel.Name = "sSurLabel";
            this.sSurLabel.Size = new System.Drawing.Size(122, 25);
            this.sSurLabel.TabIndex = 27;
            // 
            // netLabel
            // 
            this.netLabel.AutoSize = true;
            this.netLabel.Location = new System.Drawing.Point(45, 205);
            this.netLabel.Name = "netLabel";
            this.netLabel.Size = new System.Drawing.Size(73, 20);
            this.netLabel.TabIndex = 30;
            this.netLabel.Text = "Net Total:";
            // 
            // taxLabel
            // 
            this.taxLabel.AutoSize = true;
            this.taxLabel.Location = new System.Drawing.Point(45, 160);
            this.taxLabel.Name = "taxLabel";
            this.taxLabel.Size = new System.Drawing.Size(33, 20);
            this.taxLabel.TabIndex = 28;
            this.taxLabel.Text = "Tax:";
            // 
            // surLabel
            // 
            this.surLabel.AutoSize = true;
            this.surLabel.Location = new System.Drawing.Point(45, 105);
            this.surLabel.Name = "surLabel";
            this.surLabel.Size = new System.Drawing.Size(84, 20);
            this.surLabel.TabIndex = 26;
            this.surLabel.Text = "Surcharges:";
            // 
            // sSubLabel
            // 
            this.sSubLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sSubLabel.Location = new System.Drawing.Point(142, 53);
            this.sSubLabel.Name = "sSubLabel";
            this.sSubLabel.Size = new System.Drawing.Size(122, 25);
            this.sSubLabel.TabIndex = 25;
            // 
            // subLabel
            // 
            this.subLabel.AutoSize = true;
            this.subLabel.Location = new System.Drawing.Point(45, 58);
            this.subLabel.Name = "subLabel";
            this.subLabel.Size = new System.Drawing.Size(68, 20);
            this.subLabel.TabIndex = 24;
            this.subLabel.Text = "Subtotal:";
            // 
            // newOrderButton
            // 
            this.newOrderButton.Location = new System.Drawing.Point(761, 356);
            this.newOrderButton.Name = "newOrderButton";
            this.newOrderButton.Size = new System.Drawing.Size(105, 49);
            this.newOrderButton.TabIndex = 32;
            this.newOrderButton.Text = "&New Order";
            this.newOrderButton.UseVisualStyleBackColor = true;
            this.newOrderButton.Click += new System.EventHandler(this.newOrderButton_Click);
            // 
            // summaryButton
            // 
            this.summaryButton.Location = new System.Drawing.Point(761, 429);
            this.summaryButton.Name = "summaryButton";
            this.summaryButton.Size = new System.Drawing.Size(105, 49);
            this.summaryButton.TabIndex = 33;
            this.summaryButton.Text = "&Summary";
            this.summaryButton.UseVisualStyleBackColor = true;
            this.summaryButton.Click += new System.EventHandler(this.summaryButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(761, 504);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(105, 49);
            this.exitButton.TabIndex = 34;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // discountAmountLabel
            // 
            this.discountAmountLabel.AutoSize = true;
            this.discountAmountLabel.Location = new System.Drawing.Point(397, 576);
            this.discountAmountLabel.Name = "discountAmountLabel";
            this.discountAmountLabel.Size = new System.Drawing.Size(127, 20);
            this.discountAmountLabel.TabIndex = 35;
            this.discountAmountLabel.Text = "Discount Amount:";
            // 
            // sDiscountAmountLabel
            // 
            this.sDiscountAmountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sDiscountAmountLabel.Location = new System.Drawing.Point(537, 571);
            this.sDiscountAmountLabel.Name = "sDiscountAmountLabel";
            this.sDiscountAmountLabel.Size = new System.Drawing.Size(122, 25);
            this.sDiscountAmountLabel.TabIndex = 36;
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Location = new System.Drawing.Point(397, 612);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(45, 20);
            this.totalLabel.TabIndex = 37;
            this.totalLabel.Text = "Total:";
            // 
            // sTotalLabel
            // 
            this.sTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sTotalLabel.Location = new System.Drawing.Point(537, 607);
            this.sTotalLabel.Name = "sTotalLabel";
            this.sTotalLabel.Size = new System.Drawing.Size(122, 25);
            this.sTotalLabel.TabIndex = 38;
            // 
            // discountTextBox
            // 
            this.discountTextBox.Location = new System.Drawing.Point(142, 605);
            this.discountTextBox.Name = "discountTextBox";
            this.discountTextBox.Size = new System.Drawing.Size(125, 27);
            this.discountTextBox.TabIndex = 40;
            this.discountTextBox.Visible = false;
            // 
            // discountButton
            // 
            this.discountButton.Location = new System.Drawing.Point(278, 583);
            this.discountButton.Name = "discountButton";
            this.discountButton.Size = new System.Drawing.Size(105, 49);
            this.discountButton.TabIndex = 41;
            this.discountButton.Text = "A&pply Discount";
            this.discountButton.UseVisualStyleBackColor = true;
            this.discountButton.Visible = false;
            this.discountButton.Click += new System.EventHandler(this.discountButton_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.calcButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(892, 646);
            this.Controls.Add(this.discountButton);
            this.Controls.Add(this.discountTextBox);
            this.Controls.Add(this.sTotalLabel);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.sDiscountAmountLabel);
            this.Controls.Add(this.discountAmountLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.summaryButton);
            this.Controls.Add(this.newOrderButton);
            this.Controls.Add(this.totalGroupBox);
            this.Controls.Add(this.discountLabel);
            this.Controls.Add(this.volumeCheckBox);
            this.Controls.Add(this.flavorGroupBox);
            this.Controls.Add(this.orderInfoGroupBox);
            this.Name = "Form1";
            this.Text = "Java Heaven Order";
            this.orderInfoGroupBox.ResumeLayout(false);
            this.orderInfoGroupBox.PerformLayout();
            this.menuGroupBox.ResumeLayout(false);
            this.menuGroupBox.PerformLayout();
            this.flavorGroupBox.ResumeLayout(false);
            this.flavorGroupBox.PerformLayout();
            this.totalGroupBox.ResumeLayout(false);
            this.totalGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private GroupBox orderInfoGroupBox;
        private Label quantityLabel;
        private CheckBox surchargeCheckBox;
        private TextBox quantityTextBox;
        private GroupBox menuGroupBox;
        private RadioButton brewRadioButton;
        private RadioButton halflbRadioButton;
        private RadioButton onelbRadioButton;
        private RadioButton latteRadioButton;
        private RadioButton espressoRadioButton;
        private RadioButton cappuccinoRadioButton;
        private Label sItemLabel;
        private Label itemLabel;
        private Button clearButton;
        private Button calcButton;
        private GroupBox flavorGroupBox;
        private ListBox syrupListBox;
        private Label syrupLabel;
        private Label sTotalFlavorLabel;
        private Label totalFlavorLabel;
        private Button allButton;
        private Button altButton;
        private Button addButton;
        private Button removeButton;
        private ComboBox flavorComboBox;
        private CheckBox volumeCheckBox;
        private Label discountLabel;
        private GroupBox totalGroupBox;
        private Label sNetLabel;
        private Label sTaxLabel;
        private Label sSurLabel;
        private Label netLabel;
        private Label taxLabel;
        private Label surLabel;
        private Label sSubLabel;
        private Label subLabel;
        private Button newOrderButton;
        private Button summaryButton;
        private Button exitButton;
        private Label discountAmountLabel;
        private Label sDiscountAmountLabel;
        private Label totalLabel;
        private Label sTotalLabel;
        private TextBox discountTextBox;
        private Button discountButton;
    }
}