//Kevelle Wilson 3/4/2023 Coffee Heaven
using Microsoft.VisualBasic;
using System.Windows.Forms.ComponentModel.Com2Interop;
using static System.Windows.Forms.AxHost;

namespace Project
{
    


    public partial class Form1 : Form
    {
        //Decalring varibles used throughout the program
        int totalItems, numOrders;
        double subTotal, total , dailyTotal, avgTotal, discountTotal, netTotal, flavors =0;
        string flavorInput;

        public Form1()
        {
            InitializeComponent();
            
        }
        private void quantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            // This event handler only allows digits, control characters // The symbol ! means �not�; the symbols && mean �and�. 
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) )
            {
                e.Handled = true;
                return;
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Exit Confirmation
            DialogResult dialog = MessageBox.Show("Are you sure you want to exit?", this.Text,
            MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            //If answer is yes, close the app
            if (dialog == DialogResult.Yes)
                this.Close();
        }

        private void flavorComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
           

        }

        private void syrupListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void newOrderButton_Click(object sender, EventArgs e)
        {
            //Clearing all labels and resetting multiple varibles 
            clearButton.Enabled = false;
            quantityTextBox.Text = null;
            sItemLabel.Text = null;
            sSurLabel.Text = null;
            sSubLabel.Text = null;
            sSurLabel.Text = null;
            sTaxLabel.Text = null;
            sNetLabel.Text = null;
            sDiscountAmountLabel.Text = null;
            sTotalLabel.Text = null;
            cappuccinoRadioButton.Checked = true;
            dailyTotal += total;
            numOrders += 1;
            subTotal = 0;
            total= 0;
            totalItems= 0;
            discountTotal= 0;
           


        }

        private void addButton_Click(object sender, EventArgs e)
        {
            //Adds a flavor of the user's choice
            flavorInput = flavorComboBox.Text;
            flavorComboBox.Items.Add(flavorInput);
            syrupListBox.Items.Add(flavorInput);
            flavors += 1;
       sTotalFlavorLabel.Text = flavors.ToString("");
        }

        private void allButton_Click(object sender, EventArgs e)
        {
            //Clears all flavors from both both boxes
            flavorComboBox.Items.Clear();
            syrupListBox.Items.Clear();
        }

        private void altButton_Click(object sender, EventArgs e)
        {

        }

        private void volumeCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            //Makes visible all hidden objects
            discountLabel.Visible = true;
            discountButton.Visible = true;
            discountTextBox.Visible = true;
            discountTextBox.Focus();
        }

        private void quantityTextBox_TextChanged(object sender, EventArgs e)
        {
            //Makes sure wrong info is displayed in the item amount when quantity is changed
            sItemLabel.Text = null;
        }

        private void discountButton_Click(object sender, EventArgs e)
        {
            //A discount method that only works over a certain quantity
            if (totalItems > 10 && volumeCheckBox.Checked == true)
            {
                

                double discount;
                double.TryParse(discountTextBox.Text, out discount);
                discount = discount / 100;
                discountTotal = discount * netTotal;
                sDiscountAmountLabel.Text = discountTotal.ToString("C2");
            }

        }

        private void removeButton_Click(object sender, EventArgs e)
        {
            //Removes 1 flavor from both boxes
            if (flavorComboBox.Items.Count > 0)
            {
                flavorComboBox.Items.Remove(flavorInput);
                syrupListBox.Items.Remove(flavorInput);
                flavors -=1;
                sTotalFlavorLabel.Text = flavors.ToString("");
            }
            
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clears multiple smart labels
            quantityTextBox.Text = null;
            sItemLabel.Text = null; 
            cappuccinoRadioButton.Checked = true;
            quantityTextBox.Focus();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
           
            try
            {
                
                //Calculate total # cost for the order

                //Declare the variables 
                
                int flavors, quantity;
                const double cappicuno = 3.25;
                const double espresso = 3.50;
                const double onelbbenas = 9.99;
                const double halflbbenas = 5.99;
                const double latte = 3;
                double coffeeSyrupCharge =.5;
                const double freshbrew = 2.5;
                double surcharge =0;
                
                    double itemAmount =0 ;
                
                const double salestax = .08;
               double taxTotal,totalSurcharge;
                 
                clearButton.Enabled = true;


                //Grab the input

                //Parsing the input

                int.TryParse(quantityTextBox.Text, out quantity);


                //Calculate

             
                    if (cappuccinoRadioButton.Checked == true)
                    {
                 
                    itemAmount = cappicuno * quantity;
                    }
                    if (espressoRadioButton.Checked == true)
                    {
                    
                    itemAmount = espresso * quantity;

                   
                     }
                if (latteRadioButton.Checked == true)
                {

                    itemAmount = latte * quantity;
                }
                if(onelbRadioButton.Checked == true)
                {
                    itemAmount = onelbbenas * quantity;
                }
                if (halflbRadioButton.Checked == true)
                {
                    itemAmount = halflbbenas * quantity;
                }
                if (brewRadioButton.Checked == true)
                {
                    itemAmount = freshbrew * quantity;
                }
                if(surchargeCheckBox.Checked == true && halflbRadioButton.Checked == true)
                {

                    surcharge = 1.5* quantity;
                }
               
              
                if (flavorComboBox.SelectedIndex > -1) itemAmount += quantity * coffeeSyrupCharge;
                if (syrupListBox.SelectedIndex > -1) itemAmount += quantity * coffeeSyrupCharge;


                subTotal += itemAmount;
               
                totalItems += quantity;
              
                taxTotal = salestax * subTotal;
                netTotal = subTotal + taxTotal + surcharge;
                total = subTotal + taxTotal + surcharge-discountTotal;
               



                //Display the output
                sItemLabel.Text = itemAmount.ToString("C2");
                sSubLabel.Text = subTotal.ToString("C2");
                sSurLabel.Text = surcharge.ToString("C2");
                sTaxLabel.Text = taxTotal.ToString("C2");
                sNetLabel.Text = netTotal.ToString("C2");
                sDiscountAmountLabel.Text = discountTotal.ToString("C2");
                sTotalLabel.Text = total.ToString("C2");
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Quantity text box should not be blank or contain a non-numeric entry");


            }
        }

        private void discountLabel_Click(object sender, EventArgs e)
        {

        }

        private void latteRadioButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void summaryButton_Click(object sender, EventArgs e)
        {
            //A button that summarizes mutiple summary varibles
            if (numOrders > 0)
            {
                dailyTotal += total;
                avgTotal = dailyTotal / numOrders;
               
                MessageBox.Show("Total number of orders: "+numOrders+"\nDaily order totals: " +dailyTotal+ "\nThe average cost of each order: "+ avgTotal, "Summary Order");
            }
        
        }
    }
    }
